<?php
require '../database.php';
require_admin();

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $t = trim($_POST['title'] ?? '');
    $a = trim($_POST['author'] ?? '');
    $isbn = trim($_POST['isbn'] ?? '');
    $cat = trim($_POST['category'] ?? '');
    $qty = max(0, (int)($_POST['quantity'] ?? 0));
    $desc = trim($_POST['description'] ?? '');

    if ($t && $a) {

        $s = $conn->prepare(
            "INSERT INTO books
            (title,author,isbn,category,quantity,available,description)
            VALUES (?,?,?,?,?,?,?)"
        );

        $s->bind_param(
            "ssssiis",
            $t,
            $a,
            $isbn,
            $cat,
            $qty,
            $qty,
            $desc
        );

        if ($s->execute()) {

            header("Location: books.php");
            exit;

        } else {

            $msg = "Could not save book.";

        }

    } else {

        $msg = "Please enter the book title and author.";

    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Add Book - College Library</title>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            min-height: 100vh;
            background: #f4f6fb;
            color: #333;
        }

        /* HEADER */

        header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 18px 6%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .logo {
            font-size: 21px;
            font-weight: bold;
        }

        nav {
            display: flex;
            gap: 8px;
        }

        nav a {
            color: white;
            text-decoration: none;
            padding: 9px 13px;
            border-radius: 7px;
            font-size: 14px;
        }

        nav a:hover {
            background: rgba(255,255,255,0.2);
        }

        /* CONTAINER */

        .container {
            width: 90%;
            max-width: 750px;
            margin: 45px auto;
        }

        .form-card {
            background: white;
            padding: 35px;
            border-radius: 18px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.08);
        }

        .heading {
            margin-bottom: 25px;
        }

        .heading h1 {
            font-size: 28px;
            color: #2d3436;
            margin-bottom: 7px;
        }

        .heading p {
            color: #777;
            font-size: 14px;
        }

        /* ERROR */

        .error {
            background: #ffe7e7;
            color: #c0392b;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        /* FORM */

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 18px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
            color: #444;
            font-size: 14px;
        }

        .required {
            color: #e74c3c;
        }

        input,
        textarea {
            width: 100%;
            padding: 12px 13px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            outline: none;
            transition: 0.2s;
        }

        input:focus,
        textarea:focus {
            border-color: #667eea;
            box-shadow: 0 0 5px rgba(102,126,234,0.2);
        }

        textarea {
            min-height: 120px;
            resize: vertical;
        }

        .hint {
            margin-top: 5px;
            color: #999;
            font-size: 12px;
        }

        /* BUTTONS */

        .buttons {
            display: flex;
            gap: 12px;
            margin-top: 10px;
        }

        .save-btn {
            flex: 1;
            border: none;
            background: #667eea;
            color: white;
            padding: 13px;
            border-radius: 8px;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        .save-btn:hover {
            background: #5568d9;
            transform: translateY(-1px);
        }

        .back-btn {
            flex: 1;
            text-align: center;
            text-decoration: none;
            background: #eee;
            color: #444;
            padding: 13px;
            border-radius: 8px;
            font-weight: bold;
        }

        .back-btn:hover {
            background: #ddd;
        }

        /* MOBILE */

        @media (max-width: 600px) {

            header {
                flex-direction: column;
                gap: 15px;
            }

            nav {
                flex-wrap: wrap;
                justify-content: center;
            }

            .container {
                width: 94%;
                margin: 25px auto;
            }

            .form-card {
                padding: 25px 20px;
            }

            .form-row {
                grid-template-columns: 1fr;
                gap: 0;
            }

            .buttons {
                flex-direction: column;
            }

        }

    </style>

</head>

<body>

<header>

    <div class="logo">
        📚 College Library Admin
    </div>

    <nav>

        <a href="dashboard.php">Dashboard</a>

        <a href="books.php">📚 Books</a>

        <a href="students.php">👨‍🎓 Students</a>

        <a href="issues.php">📋 Requests</a>

    </nav>

</header>


<main class="container">

    <div class="form-card">

        <div class="heading">

            <h1>➕ Add New Book</h1>

            <p>
                Enter the details below to add a new book to the library.
            </p>

        </div>


        <?php if ($msg): ?>

            <div class="error">
                ⚠️ <?= e($msg) ?>
            </div>

        <?php endif; ?>


        <form method="post">

            <!-- TITLE + AUTHOR -->

            <div class="form-row">

                <div class="form-group">

                    <label>
                        Book Title <span class="required">*</span>
                    </label>

                    <input
                        type="text"
                        name="title"
                        placeholder="Enter book title"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>
                        Author <span class="required">*</span>
                    </label>

                    <input
                        type="text"
                        name="author"
                        placeholder="Enter author name"
                        required
                    >

                </div>

            </div>


            <!-- ISBN + CATEGORY -->

            <div class="form-row">

                <div class="form-group">

                    <label>ISBN</label>

                    <input
                        type="text"
                        name="isbn"
                        placeholder="Enter ISBN number"
                    >

                    <p class="hint">
                        Example: 9780135166307
                    </p>

                </div>


                <div class="form-group">

                    <label>Category</label>

                    <input
                        type="text"
                        name="category"
                        placeholder="Example: Programming"
                    >

                </div>

            </div>


            <!-- QUANTITY -->

            <div class="form-group">

                <label>
                    Quantity <span class="required">*</span>
                </label>

                <input
                    type="number"
                    name="quantity"
                    min="0"
                    value="1"
                    required
                >

                <p class="hint">
                    Number of copies available in the library.
                </p>

            </div>


            <!-- DESCRIPTION -->

            <div class="form-group">

                <label>Description</label>

                <textarea
                    name="description"
                    placeholder="Enter a short description of the book..."
                ></textarea>

            </div>


            <!-- BUTTONS -->

            <div class="buttons">

                <button type="submit" class="save-btn">
                    💾 Save Book
                </button>

                <a href="books.php" class="back-btn">
                    ← Back to Books
                </a>

            </div>

        </form>

    </div>

</main>

</body>

</html>