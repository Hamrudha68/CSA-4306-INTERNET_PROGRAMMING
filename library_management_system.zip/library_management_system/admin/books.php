<?php
require '../database.php';
require_admin();

$rows = $conn->query("SELECT * FROM books ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Manage Books - College Library</title>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f4f6fb;
            color: #333;
        }

        /* HEADER */

        header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 18px 6%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .logo {
            font-size: 22px;
            font-weight: bold;
        }

        nav {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        nav a {
            color: white;
            text-decoration: none;
            padding: 9px 13px;
            border-radius: 7px;
            font-size: 14px;
        }

        nav a:hover {
            background: rgba(255,255,255,0.2);
        }

        /* MAIN */

        .container {
            width: 92%;
            max-width: 1200px;
            margin: 40px auto;
        }

        .top-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            gap: 20px;
        }

        h1 {
            color: #2d3436;
            margin-bottom: 5px;
        }

        .subtitle {
            color: #777;
            font-size: 14px;
        }

        .add-btn {
            background: #667eea;
            color: white;
            text-decoration: none;
            padding: 12px 18px;
            border-radius: 8px;
            font-weight: bold;
            transition: 0.3s;
            white-space: nowrap;
        }

        .add-btn:hover {
            background: #5568d9;
            transform: translateY(-2px);
        }

        /* SEARCH */

        .search-box {
            background: white;
            padding: 18px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.06);
        }

        .search-box input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 15px;
            outline: none;
        }

        .search-box input:focus {
            border-color: #667eea;
        }

        /* TABLE */

        .table-container {
            background: white;
            border-radius: 14px;
            overflow-x: auto;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 750px;
        }

        th {
            background: #667eea;
            color: white;
            padding: 15px;
            text-align: left;
            font-size: 14px;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #eee;
            font-size: 14px;
        }

        tr:hover td {
            background: #f8f8ff;
        }

        /* AVAILABILITY */

        .available {
            display: inline-block;
            background: #e6f8ed;
            color: #1e8449;
            padding: 6px 10px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 12px;
        }

        .unavailable {
            display: inline-block;
            background: #ffe7e7;
            color: #c0392b;
            padding: 6px 10px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 12px;
        }

        /* ACTIONS */

        .edit {
            color: #667eea;
            text-decoration: none;
            font-weight: bold;
        }

        .delete {
            color: #e74c3c;
            text-decoration: none;
            font-weight: bold;
        }

        .edit:hover,
        .delete:hover {
            text-decoration: underline;
        }

        .empty {
            text-align: center;
            padding: 40px;
            color: #777;
        }

        /* MOBILE */

        @media (max-width: 650px) {

            header {
                flex-direction: column;
                gap: 15px;
            }

            .top-section {
                flex-direction: column;
                align-items: flex-start;
            }

            .add-btn {
                width: 100%;
                text-align: center;
            }

        }

    </style>

</head>

<body>

<header>

    <div class="logo">
        📚 College Library Admin
    </div>

    <nav>

        <a href="dashboard.php">Dashboard</a>

        <a href="books.php">📚 Books</a>

        <a href="students.php">👨‍🎓 Students</a>

        <a href="issues.php">📋 Requests</a>

        <a href="../logout.php">Logout</a>

    </nav>

</header>


<main class="container">

    <div class="top-section">

        <div>

            <h1>📚 Manage Books</h1>

            <p class="subtitle">
                Add, edit, search and manage library books.
            </p>

        </div>

        <a href="add_book.php" class="add-btn">
            ➕ Add New Book
        </a>

    </div>


    <!-- SEARCH -->

    <div class="search-box">

        <input
            type="text"
            id="bookSearch"
            placeholder="🔍 Search by book title, author or ID..."
            onkeyup="searchBooks()"
        >

    </div>


    <!-- BOOK TABLE -->

    <div class="table-container">

        <table id="booksTable">

            <thead>

                <tr>

                    <th>ID</th>

                    <th>Title</th>

                    <th>Author</th>

                    <th>Quantity</th>

                    <th>Availability</th>

                    <th>Actions</th>

                </tr>

            </thead>

            <tbody>

            <?php if ($rows->num_rows > 0): ?>

                <?php while ($b = $rows->fetch_assoc()): ?>

                    <tr>

                        <td>
                            #<?= e($b['id']) ?>
                        </td>

                        <td>
                            <strong><?= e($b['title']) ?></strong>
                        </td>

                        <td>
                            <?= e($b['author']) ?>
                        </td>

                        <td>
                            <?= e($b['quantity']) ?>
                        </td>

                        <td>

                            <?php if ($b['available'] > 0): ?>

                                <span class="available">
                                    🟢 <?= e($b['available']) ?> Available
                                </span>

                            <?php else: ?>

                                <span class="unavailable">
                                    🔴 Not Available
                                </span>

                            <?php endif; ?>

                        </td>

                        <td>

                            <a
                                href="edit_book.php?id=<?= e($b['id']) ?>"
                                class="edit"
                            >
                                ✏️ Edit
                            </a>

                            &nbsp; | &nbsp;

                            <a
                                href="delete_book.php?id=<?= e($b['id']) ?>"
                                class="delete"
                                data-confirm="Delete this book?"
                            >
                                🗑️ Delete
                            </a>

                        </td>

                    </tr>

                <?php endwhile; ?>

            <?php else: ?>

                <tr>

                    <td colspan="6" class="empty">

                        📚 No books found in the library.

                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</main>


<script>

function searchBooks() {

    let input = document.getElementById("bookSearch");
    let filter = input.value.toLowerCase();

    let table = document.getElementById("booksTable");
    let rows = table.getElementsByTagName("tr");

    for (let i = 1; i < rows.length; i++) {

        let text = rows[i].textContent.toLowerCase();

        if (text.includes(filter)) {
            rows[i].style.display = "";
        } else {
            rows[i].style.display = "none";
        }

    }

}

</script>

</body>

</html>