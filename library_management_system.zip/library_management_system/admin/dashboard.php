<?php
require '../database.php';
require_admin();

$books = $conn->query("SELECT COUNT(*) n FROM books")->fetch_assoc()['n'];
$users = $conn->query("SELECT COUNT(*) n FROM users")->fetch_assoc()['n'];
$pending = $conn->query("SELECT COUNT(*) n FROM issues WHERE status='Pending'")->fetch_assoc()['n'];
$issued = $conn->query("SELECT COUNT(*) n FROM issues WHERE status='Issued'")->fetch_assoc()['n'];
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard - College Library</title>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f4f6fb;
            color: #333;
        }

        /* HEADER */

        header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 18px 6%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .logo {
            font-size: 22px;
            font-weight: bold;
        }

        .logo span {
            margin-right: 8px;
        }

        nav {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        nav a {
            color: white;
            text-decoration: none;
            padding: 9px 14px;
            border-radius: 7px;
            font-size: 14px;
            transition: 0.3s;
        }

        nav a:hover {
            background: rgba(255,255,255,0.2);
        }

        .logout {
            background: rgba(255,255,255,0.2);
        }

        /* MAIN */

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 40px auto;
        }

        .welcome {
            margin-bottom: 30px;
        }

        .welcome h1 {
            font-size: 30px;
            margin-bottom: 8px;
            color: #2d3436;
        }

        .welcome p {
            color: #777;
        }

        /* STATISTICS */

        .grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 35px;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 18px rgba(0,0,0,0.08);
            transition: 0.3s;
            border-left: 5px solid #667eea;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.12);
        }

        .card-icon {
            font-size: 30px;
            margin-bottom: 12px;
        }

        .card p {
            color: #777;
            font-size: 14px;
            margin-bottom: 8px;
        }

        .card h2 {
            font-size: 30px;
            color: #333;
        }

        /* QUICK ACTIONS */

        .section-title {
            margin-bottom: 15px;
            font-size: 21px;
        }

        .actions {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
        }

        .action {
            background: white;
            padding: 20px;
            border-radius: 12px;
            text-decoration: none;
            color: #333;
            box-shadow: 0 4px 15px rgba(0,0,0,0.07);
            transition: 0.3s;
        }

        .action:hover {
            transform: translateY(-3px);
            background: #f8f8ff;
        }

        .action-icon {
            font-size: 28px;
            margin-bottom: 10px;
        }

        .action h3 {
            margin-bottom: 5px;
        }

        .action p {
            font-size: 13px;
            color: #777;
        }

        /* FOOTER */

        footer {
            text-align: center;
            margin-top: 50px;
            padding: 20px;
            color: #888;
            font-size: 13px;
        }

        /* MOBILE */

        @media (max-width: 900px) {

            .grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .actions {
                grid-template-columns: repeat(2, 1fr);
            }

        }

        @media (max-width: 600px) {

            header {
                flex-direction: column;
                gap: 15px;
            }

            nav {
                flex-wrap: wrap;
                justify-content: center;
            }

            .grid {
                grid-template-columns: 1fr;
            }

            .actions {
                grid-template-columns: 1fr;
            }

            .welcome h1 {
                font-size: 25px;
            }

        }

    </style>

</head>

<body>

<header>

    <div class="logo">
        <span>📚</span> College Library Admin
    </div>

    <nav>

        <a href="dashboard.php">Dashboard</a>

        <a href="books.php">📚 Books</a>

        <a href="students.php">👨‍🎓 Students</a>

        <a href="issues.php">📋 Requests</a>

        <a href="../logout.php" class="logout">Logout</a>

    </nav>

</header>


<main class="container">

    <div class="welcome">

        <h1>📊 Admin Dashboard</h1>

        <p>Welcome to the College Library Management System.</p>

    </div>


    <!-- STATISTICS -->

    <div class="grid">

        <div class="card">

            <div class="card-icon">📚</div>

            <p>Total Books</p>

            <h2><?= e($books) ?></h2>

        </div>


        <div class="card">

            <div class="card-icon">👨‍🎓</div>

            <p>Registered Students</p>

            <h2><?= e($users) ?></h2>

        </div>


        <div class="card">

            <div class="card-icon">⏳</div>

            <p>Pending Requests</p>

            <h2><?= e($pending) ?></h2>

        </div>


        <div class="card">

            <div class="card-icon">📖</div>

            <p>Currently Issued</p>

            <h2><?= e($issued) ?></h2>

        </div>

    </div>


    <!-- QUICK ACTIONS -->

    <h2 class="section-title">Quick Actions</h2>

    <div class="actions">

        <a href="books.php" class="action">

            <div class="action-icon">📚</div>

            <h3>Manage Books</h3>

            <p>Add, edit or delete library books.</p>

        </a>


        <a href="students.php" class="action">

            <div class="action-icon">👨‍🎓</div>

            <h3>Students</h3>

            <p>View registered library students.</p>

        </a>


        <a href="issues.php" class="action">

            <div class="action-icon">📋</div>

            <h3>Issue Requests</h3>

            <p>Manage pending and issued books.</p>

        </a>


        <a href="../logout.php" class="action">

            <div class="action-icon">🚪</div>

            <h3>Logout</h3>

            <p>Securely logout from admin panel.</p>

        </a>

    </div>

</main>


<footer>

    © 2026 College Library Management System

</footer>

</body>

</html>