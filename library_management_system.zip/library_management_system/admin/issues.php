<?php
require '../database.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id = (int)($_POST['id'] ?? 0);
    $action = $_POST['action'] ?? '';

    $s = $conn->prepare("SELECT book_id,status FROM issues WHERE id=?");
    $s->bind_param("i", $id);
    $s->execute();

    $r = $s->get_result()->fetch_assoc();

    /* APPROVE REQUEST */
    if ($r && $r['status'] === 'Pending' && $action === 'approve') {

        $conn->begin_transaction();

        $q = $conn->prepare(
            "UPDATE books 
             SET available=available-1 
             WHERE id=? AND available>0"
        );

        $q->bind_param("i", $r['book_id']);
        $q->execute();

        if ($q->affected_rows) {

            $q = $conn->prepare(
                "UPDATE issues 
                 SET status='Issued' 
                 WHERE id=?"
            );

            $q->bind_param("i", $id);
            $q->execute();

            $conn->commit();

        } else {

            $conn->rollback();
        }
    }

    /* REJECT REQUEST */
    elseif ($r && $r['status'] === 'Pending' && $action === 'reject') {

        $q = $conn->prepare(
            "UPDATE issues 
             SET status='Rejected' 
             WHERE id=?"
        );

        $q->bind_param("i", $id);
        $q->execute();
    }

    header("Location: issues.php");
    exit;
}


/* GET ALL REQUESTS */
$rows = $conn->query(
    "SELECT i.*,u.name,u.email,b.title 
     FROM issues i 
     JOIN users u ON u.id=i.user_id 
     JOIN books b ON b.id=i.book_id 
     ORDER BY i.id DESC"
);

?>

<!doctype html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Book Requests</title>

    <link rel="stylesheet" href="../style.css">

    <style>

        body {
            background: #f4f7fb;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 18px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }

        header b {
            font-size: 24px;
        }

        nav {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        nav a {
            color: white;
            text-decoration: none;
            padding: 9px 14px;
            border-radius: 8px;
            transition: 0.3s;
        }

        nav a:hover {
            background: rgba(255,255,255,0.2);
        }

        .container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .page-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 25px;
        }

        h1 {
            margin: 0;
            color: #222;
        }

        .request-count {
            background: white;
            padding: 12px 18px;
            border-radius: 10px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
            color: #555;
        }

        .search-box {
            background: white;
            padding: 18px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
        }

        .search-box input {
            width: 100%;
            box-sizing: border-box;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 15px;
            outline: none;
        }

        .search-box input:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102,126,234,0.12);
        }

        .table-card {
            background: white;
            border-radius: 14px;
            overflow-x: auto;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 950px;
        }

        th {
            background: #667eea;
            color: white;
            padding: 15px;
            text-align: left;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #eee;
            color: #444;
            vertical-align: middle;
        }

        tr:hover td {
            background: #f8f9ff;
        }

        .student-name {
            font-weight: bold;
            color: #333;
        }

        .email {
            font-size: 13px;
            color: #777;
            margin-top: 4px;
        }

        .book-title {
            font-weight: bold;
            color: #667eea;
        }

        .date {
            font-size: 14px;
            line-height: 1.7;
        }

        .status {
            display: inline-block;
            padding: 7px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: bold;
        }

        .status-pending {
            background: #fff3cd;
            color: #856404;
        }

        .status-issued {
            background: #d1ecf1;
            color: #0c5460;
        }

        .status-rejected {
            background: #f8d7da;
            color: #721c24;
        }

        .status-returned {
            background: #d4edda;
            color: #155724;
        }

        .actions {
            white-space: nowrap;
        }

        .actions form {
            display: inline;
        }

        button {
            border: none;
            padding: 9px 13px;
            border-radius: 7px;
            cursor: pointer;
            font-size: 13px;
            font-weight: bold;
            background: #667eea;
            color: white;
            transition: 0.3s;
        }

        button:hover {
            opacity: 0.85;
            transform: translateY(-1px);
        }

        button.secondary {
            background: #dc3545;
        }

        button.return {
            background: #28a745;
        }

        .no-action {
            color: #999;
            font-size: 13px;
        }

        .empty {
            text-align: center;
            padding: 35px;
            color: #888;
        }

        @media (max-width: 700px) {

            header {
                padding: 18px 20px;
            }

            header b {
                font-size: 20px;
            }

            .container {
                margin: 25px auto;
            }

        }

    </style>

</head>

<body>

<header>

    <b>📚 Library Admin</b>

    <nav>

        <a href="dashboard.php">Dashboard</a>

        <a href="books.php">Books</a>

        <a href="students.php">Students</a>

        <a href="issues.php">Requests</a>

        <a href="../logout.php">Logout</a>

    </nav>

</header>


<main class="container">

    <div class="page-title">

        <h1>📋 Book Requests & Issues</h1>

        <div class="request-count">
            Total Requests:
            <strong><?= $rows->num_rows ?></strong>
        </div>

    </div>


    <div class="search-box">

        <input
            type="text"
            id="requestSearch"
            placeholder="🔍 Search by student, email, or book..."
            onkeyup="searchRequests()"
        >

    </div>


    <div class="table-card">

        <table id="requestsTable">

            <thead>

                <tr>
                    <th>Student</th>
                    <th>Book</th>
                    <th>Issue / Due Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>

            </thead>

            <tbody>

            <?php if ($rows->num_rows > 0): ?>

                <?php while ($r = $rows->fetch_assoc()): ?>

                    <tr>

                        <td>

                            <div class="student-name">
                                <?= e($r['name']) ?>
                            </div>

                            <div class="email">
                                <?= e($r['email']) ?>
                            </div>

                        </td>


                        <td>

                            <div class="book-title">
                                📖 <?= e($r['title']) ?>
                            </div>

                        </td>


                        <td class="date">

                            <strong>Issue:</strong>
                            <?= e($r['issue_date']) ?>

                            <br>

                            <strong>Due:</strong>
                            <?= e($r['due_date']) ?>

                        </td>


                        <td>

                            <?php if ($r['status'] === 'Pending'): ?>

                                <span class="status status-pending">
                                    ⏳ Pending
                                </span>

                            <?php elseif ($r['status'] === 'Issued'): ?>

                                <span class="status status-issued">
                                    📚 Issued
                                </span>

                            <?php elseif ($r['status'] === 'Rejected'): ?>

                                <span class="status status-rejected">
                                    ❌ Rejected
                                </span>

                            <?php elseif ($r['status'] === 'Returned'): ?>

                                <span class="status status-returned">
                                    ✅ Returned
                                </span>

                            <?php else: ?>

                                <span class="status">
                                    <?= e($r['status']) ?>
                                </span>

                            <?php endif; ?>

                        </td>


                        <td class="actions">

                            <?php if ($r['status'] === 'Pending'): ?>

                                <form method="post">

                                    <input
                                        type="hidden"
                                        name="id"
                                        value="<?= e($r['id']) ?>"
                                    >

                                    <button
                                        type="submit"
                                        name="action"
                                        value="approve"
                                    >
                                        ✅ Approve
                                    </button>

                                    <button
                                        type="submit"
                                        name="action"
                                        value="reject"
                                        class="secondary"
                                    >
                                        ❌ Reject
                                    </button>

                                </form>


                            <?php elseif ($r['status'] === 'Issued'): ?>

                                <form
                                    method="post"
                                    action="return.php"
                                >

                                    <input
                                        type="hidden"
                                        name="id"
                                        value="<?= e($r['id']) ?>"
                                    >

                                    <button
                                        type="submit"
                                        class="return"
                                    >
                                        🔄 Mark Returned
                                    </button>

                                </form>


                            <?php else: ?>

                                <span class="no-action">
                                    No action
                                </span>

                            <?php endif; ?>

                        </td>

                    </tr>

                <?php endwhile; ?>

            <?php else: ?>

                <tr>

                    <td colspan="5" class="empty">

                        📭 No book requests found.

                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</main>


<script>

function searchRequests() {

    const input = document.getElementById("requestSearch");

    const filter = input.value.toLowerCase();

    const table = document.getElementById("requestsTable");

    const rows = table.getElementsByTagName("tr");


    for (let i = 1; i < rows.length; i++) {

        const text = rows[i].textContent.toLowerCase();

        if (text.includes(filter)) {

            rows[i].style.display = "";

        } else {

            rows[i].style.display = "none";

        }

    }

}

</script>

</body>

</html>