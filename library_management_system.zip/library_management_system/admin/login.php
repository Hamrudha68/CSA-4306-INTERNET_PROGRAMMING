<?php
require '../database.php';

if (!empty($_SESSION['admin_id'])) {
    header("Location: dashboard.php");
    exit;
}

$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $u = trim($_POST['username'] ?? '');
    $p = $_POST['password'] ?? '';

    $s = $conn->prepare("SELECT id,password FROM admins WHERE username=?");
    $s->bind_param("s", $u);
    $s->execute();

    $a = $s->get_result()->fetch_assoc();

    if ($a && password_verify($p, $a['password'])) {

        session_regenerate_id(true);

        $_SESSION['admin_id'] = $a['id'];
        $_SESSION['admin_name'] = $u;

        header("Location: dashboard.php");
        exit;

    } else {
        $err = "Invalid admin credentials.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Admin Login - College Library</title>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #667eea, #764ba2);
        }

        .login-container {
            width: 400px;
            background: white;
            padding: 40px;
            border-radius: 18px;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.25);
        }

        .logo {
            text-align: center;
            font-size: 50px;
            margin-bottom: 10px;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 5px;
        }

        .subtitle {
            text-align: center;
            color: #777;
            margin-bottom: 30px;
            font-size: 14px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            color: #444;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 13px;
            margin-bottom: 18px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 15px;
            outline: none;
        }

        input:focus {
            border-color: #667eea;
            box-shadow: 0 0 5px rgba(102, 126, 234, 0.3);
        }

        .password-box {
            position: relative;
        }

        .password-box input {
            padding-right: 65px;
        }

        .show-password {
            position: absolute;
            right: 12px;
            top: 12px;
            color: #667eea;
            cursor: pointer;
            font-size: 13px;
            font-weight: bold;
        }

        button {
            width: 100%;
            padding: 13px;
            border: none;
            border-radius: 8px;
            background: #667eea;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        button:hover {
            background: #5568d9;
            transform: translateY(-1px);
        }

        .error {
            background: #ffe5e5;
            color: #d63031;
            padding: 10px;
            border-radius: 7px;
            text-align: center;
            margin-bottom: 18px;
            font-size: 14px;
        }

        .default-info {
            margin-top: 20px;
            padding: 12px;
            background: #f5f5f5;
            border-radius: 8px;
            text-align: center;
            color: #666;
            font-size: 12px;
        }

        .home {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: bold;
        }

        .home:hover {
            text-decoration: underline;
        }

        @media (max-width: 450px) {

            .login-container {
                width: 90%;
                padding: 30px 25px;
            }

        }

    </style>

</head>

<body>

    <div class="login-container">

        <div class="logo">📚</div>

        <h1>Admin Login</h1>

        <p class="subtitle">
            College Library Management System
        </p>

        <?php if ($err): ?>

            <p class="error">
                <?php echo e($err); ?>
            </p>

        <?php endif; ?>

        <form method="post">

            <label>Username</label>

            <input
                type="text"
                name="username"
                placeholder="Enter admin username"
                required
            >

            <label>Password</label>

            <div class="password-box">

                <input
                    type="password"
                    name="password"
                    id="password"
                    placeholder="Enter password"
                    required
                >

                <span
                    class="show-password"
                    onclick="togglePassword()"
                    id="toggleText"
                >
                    Show
                </span>

            </div>

            <button type="submit">
                🔐 Login
            </button>

        </form>

        <div class="default-info">
            Default login: <b>admin</b> / <b>admin123</b>
        </div>

        <a href="../index.php" class="home">
            ← Back to Home
        </a>

    </div>

    <script>

        function togglePassword() {

            const password = document.getElementById("password");
            const toggleText = document.getElementById("toggleText");

            if (password.type === "password") {

                password.type = "text";
                toggleText.textContent = "Hide";

            } else {

                password.type = "password";
                toggleText.textContent = "Show";

            }
        }

    </script>

</body>

</html>