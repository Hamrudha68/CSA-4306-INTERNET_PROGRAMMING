<?php

require '../database.php';
require_admin();

$id = (int)($_POST['id'] ?? 0);

if ($id > 0) {

    $s = $conn->prepare(
        "SELECT book_id, status
         FROM issues
         WHERE id=?"
    );

    $s->bind_param("i", $id);
    $s->execute();

    $r = $s->get_result()->fetch_assoc();

    if ($r && $r['status'] === 'Issued') {

        $conn->begin_transaction();

        /* Mark book as returned */
        $q = $conn->prepare(
            "UPDATE issues
             SET status='Returned', return_date=CURDATE()
             WHERE id=? AND status='Issued'"
        );

        $q->bind_param("i", $id);
        $q->execute();

        if ($q->affected_rows) {

            /* Increase available book count */
            $q = $conn->prepare(
                "UPDATE books
                 SET available=available+1
                 WHERE id=?"
            );

            $q->bind_param("i", $r['book_id']);
            $q->execute();

            $conn->commit();

        } else {

            $conn->rollback();
        }
    }
}

header("Location: issues.php");
exit;

?>