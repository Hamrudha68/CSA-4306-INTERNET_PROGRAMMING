<?php
require '../database.php';
require_admin();

$rows = $conn->query("SELECT id,name,email,created_at FROM users ORDER BY id DESC");
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Registered Students</title>

    <link rel="stylesheet" href="../style.css">

    <style>
        body {
            background: #f4f7fb;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 18px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }

        header b {
            font-size: 24px;
        }

        nav {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        nav a {
            color: white;
            text-decoration: none;
            padding: 9px 14px;
            border-radius: 8px;
            transition: 0.3s;
        }

        nav a:hover {
            background: rgba(255,255,255,0.2);
        }

        .container {
            max-width: 1100px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .page-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 25px;
        }

        h1 {
            color: #222;
            margin: 0;
        }

        .student-count {
            background: white;
            padding: 12px 18px;
            border-radius: 10px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
            color: #555;
        }

        .search-box {
            background: white;
            padding: 18px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
        }

        .search-box input {
            width: 100%;
            box-sizing: border-box;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 15px;
            outline: none;
        }

        .search-box input:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102,126,234,0.12);
        }

        .table-card {
            background: white;
            border-radius: 14px;
            overflow-x: auto;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 650px;
        }

        th {
            background: #667eea;
            color: white;
            padding: 15px;
            text-align: left;
        }

        td {
            padding: 14px 15px;
            border-bottom: 1px solid #eee;
            color: #444;
        }

        tr:hover td {
            background: #f8f9ff;
        }

        .student-id {
            font-weight: bold;
            color: #667eea;
        }

        .email {
            color: #555;
        }

        .empty {
            text-align: center;
            padding: 30px;
            color: #888;
        }

        @media (max-width: 700px) {
            header {
                padding: 18px 20px;
            }

            .container {
                margin: 25px auto;
            }

            header b {
                font-size: 20px;
            }
        }
    </style>
</head>

<body>

<header>
    <b>📚 Library Admin</b>

    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="books.php">Books</a>
        <a href="students.php">Students</a>
        <a href="issues.php">Requests</a>
        <a href="../logout.php">Logout</a>
    </nav>
</header>

<main class="container">

    <div class="page-title">
        <h1>👨‍🎓 Registered Students</h1>

        <div class="student-count">
            Total Students:
            <strong><?= $rows->num_rows ?></strong>
        </div>
    </div>

    <div class="search-box">
        <input
            type="text"
            id="studentSearch"
            placeholder="🔍 Search by student name, email or ID..."
            onkeyup="searchStudents()"
        >
    </div>

    <div class="table-card">

        <table id="studentsTable">

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Student Name</th>
                    <th>Email Address</th>
                    <th>Registered Date</th>
                </tr>
            </thead>

            <tbody>

            <?php if ($rows->num_rows > 0): ?>

                <?php while ($u = $rows->fetch_assoc()): ?>

                    <tr>
                        <td class="student-id">
                            <?= e($u['id']) ?>
                        </td>

                        <td>
                            <?= e($u['name']) ?>
                        </td>

                        <td class="email">
                            <?= e($u['email']) ?>
                        </td>

                        <td>
                            <?= e($u['created_at']) ?>
                        </td>
                    </tr>

                <?php endwhile; ?>

            <?php else: ?>

                <tr>
                    <td colspan="4" class="empty">
                        No registered students found.
                    </td>
                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</main>

<script>
function searchStudents() {

    const input = document.getElementById("studentSearch");
    const filter = input.value.toLowerCase();

    const table = document.getElementById("studentsTable");
    const rows = table.getElementsByTagName("tr");

    for (let i = 1; i < rows.length; i++) {

        const text = rows[i].textContent.toLowerCase();

        if (text.includes(filter)) {
            rows[i].style.display = "";
        } else {
            rows[i].style.display = "none";
        }
    }
}
</script>

</body>
</html>