<?php

require 'database.php';

$id = (int)($_GET['id'] ?? 0);

$s = $conn->prepare(
    "SELECT * FROM books WHERE id=?"
);

$s->bind_param("i", $id);
$s->execute();

$b = $s->get_result()->fetch_assoc();

?>

<!doctype html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Book Details</title>

    <link rel="stylesheet" href="style.css">

    <style>

        body {
            background: #f4f7fb;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 18px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }

        .brand {
            color: white;
            text-decoration: none;
            font-size: 24px;
            font-weight: bold;
        }

        nav {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        nav a {
            color: white;
            text-decoration: none;
            padding: 9px 14px;
            border-radius: 8px;
        }

        nav a:hover {
            background: rgba(255,255,255,0.2);
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 0 20px;
        }

        .book-panel {
            background: white;
            border-radius: 18px;
            padding: 35px;
            box-shadow: 0 6px 25px rgba(0,0,0,0.08);
        }

        .book-icon {
            font-size: 55px;
            margin-bottom: 10px;
        }

        h1 {
            margin: 0 0 25px;
            color: #222;
            font-size: 32px;
        }

        .detail {
            padding: 14px 0;
            border-bottom: 1px solid #eee;
            color: #555;
        }

        .detail strong {
            display: inline-block;
            width: 120px;
            color: #333;
        }

        .availability {
            display: inline-block;
            padding: 8px 13px;
            border-radius: 20px;
            font-weight: bold;
        }

        .available {
            background: #d4edda;
            color: #155724;
        }

        .unavailable {
            background: #f8d7da;
            color: #721c24;
        }

        .description {
            margin-top: 25px;
            padding: 20px;
            background: #f8f9ff;
            border-radius: 10px;
            line-height: 1.7;
            color: #555;
        }

        .actions {
            margin-top: 30px;
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .btn {
            display: inline-block;
            padding: 12px 18px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
        }

        .btn:hover {
            opacity: 0.9;
        }

        .back-btn {
            background: #e9ecef;
            color: #333;
        }

        .unavailable-message {
            padding: 12px 16px;
            background: #fff3cd;
            color: #856404;
            border-radius: 8px;
            font-weight: bold;
        }

        .not-found {
            background: white;
            padding: 40px;
            text-align: center;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }

        @media (max-width: 700px) {

            header {
                padding: 18px 20px;
            }

            .brand {
                font-size: 20px;
            }

            .book-panel {
                padding: 25px;
            }

            h1 {
                font-size: 26px;
            }

            .detail strong {
                display: block;
                margin-bottom: 5px;
            }

        }

    </style>

</head>

<body>

<header>

    <a class="brand" href="index.php">
        📚 College Library
    </a>

    <nav>

        <a href="index.php">Home</a>

        <a href="books.php">Catalog</a>

        <a href="my_books.php">My Books</a>

        <a href="login.php">Login</a>

    </nav>

</header>


<main class="container">

<?php if (!$b): ?>

    <div class="not-found">

        <h2>📭 Book Not Found</h2>

        <p>
            The requested book could not be found.
        </p>

        <a class="btn" href="books.php">
            ← Back to Catalog
        </a>

    </div>

<?php else: ?>

    <div class="book-panel">

        <div class="book-icon">
            📖
        </div>

        <h1>
            <?= e($b['title']) ?>
        </h1>


        <div class="detail">

            <strong>Author:</strong>

            <?= e($b['author']) ?>

        </div>


        <div class="detail">

            <strong>ISBN:</strong>

            <?= e($b['isbn']) ?>

        </div>


        <div class="detail">

            <strong>Category:</strong>

            <?= e($b['category']) ?>

        </div>


        <div class="detail">

            <strong>Availability:</strong>

            <?php if ((int)$b['available'] > 0): ?>

                <span class="availability available">

                    🟢
                    <?= e($b['available']) ?>
                    available

                    / <?= e($b['quantity']) ?>

                </span>

            <?php else: ?>

                <span class="availability unavailable">

                    🔴 Not Available

                </span>

            <?php endif; ?>

        </div>


        <div class="description">

            <strong>📄 Description</strong>

            <p>
                <?= nl2br(e($b['description'])) ?>
            </p>

        </div>


        <div class="actions">

            <?php if ((int)$b['available'] > 0): ?>

                <a
                    class="btn"
                    href="borrow.php?id=<?= e($b['id']) ?>"
                >
                    📚 Request This Book
                </a>

            <?php else: ?>

                <div class="unavailable-message">
                    ⚠️ This book is currently unavailable.
                </div>

            <?php endif; ?>


            <a
                class="btn back-btn"
                href="books.php"
            >
                ← Back to Catalog
            </a>

        </div>

    </div>

<?php endif; ?>

</main>

</body>

</html>