<?php

require 'database.php';

$q = trim($_GET['q'] ?? '');

if ($q !== '') {

    $like = "%$q%";

    $s = $conn->prepare(
        "SELECT * FROM books
         WHERE title LIKE ?
         OR author LIKE ?
         OR category LIKE ?
         ORDER BY title"
    );

    $s->bind_param("sss", $like, $like, $like);
    $s->execute();

    $books = $s->get_result();

} else {

    $books = $conn->query(
        "SELECT * FROM books ORDER BY title"
    );
}

?>

<!doctype html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Book Catalog</title>

    <link rel="stylesheet" href="style.css">

    <style>

        body {
            background: #f4f7fb;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 18px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }

        .brand {
            color: white;
            text-decoration: none;
            font-size: 24px;
            font-weight: bold;
        }

        nav {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        nav a {
            color: white;
            text-decoration: none;
            padding: 9px 14px;
            border-radius: 8px;
            transition: 0.3s;
        }

        nav a:hover {
            background: rgba(255,255,255,0.2);
        }

        .container {
            max-width: 1150px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 25px;
        }

        h1 {
            margin: 0;
            color: #222;
        }

        .book-count {
            background: white;
            padding: 12px 18px;
            border-radius: 10px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
            color: #555;
        }

        .search-card {
            background: white;
            padding: 20px;
            border-radius: 14px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        .search-form {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .search-form input {
            flex: 1;
            min-width: 250px;
            padding: 13px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 15px;
            outline: none;
            box-sizing: border-box;
        }

        .search-form input:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102,126,234,0.12);
        }

        .search-form button {
            padding: 13px 20px;
            border: none;
            border-radius: 8px;
            background: #667eea;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        .clear-btn {
            display: inline-flex;
            align-items: center;
            padding: 13px 18px;
            background: #eee;
            color: #444;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(270px, 1fr));
            gap: 22px;
        }

        .book-card {
            background: white;
            border-radius: 15px;
            padding: 24px;
            box-shadow: 0 5px 18px rgba(0,0,0,0.08);
            transition: 0.3s;
            display: flex;
            flex-direction: column;
        }

        .book-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 9px 25px rgba(0,0,0,0.12);
        }

        .book-icon {
            font-size: 38px;
            margin-bottom: 10px;
        }

        .book-card h3 {
            margin: 0 0 15px;
            color: #222;
            font-size: 20px;
        }

        .book-info {
            color: #666;
            line-height: 1.7;
            margin-bottom: 6px;
        }

        .book-info strong {
            color: #444;
        }

        .availability {
            margin: 15px 0;
            padding: 10px 12px;
            border-radius: 8px;
            font-weight: bold;
        }

        .available {
            background: #d4edda;
            color: #155724;
        }

        .unavailable {
            background: #f8d7da;
            color: #721c24;
        }

        .btn {
            display: inline-block;
            margin-top: auto;
            padding: 11px 16px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            text-align: center;
            font-weight: bold;
        }

        .btn:hover {
            opacity: 0.9;
        }

        .empty {
            background: white;
            text-align: center;
            padding: 40px;
            border-radius: 14px;
            color: #777;
            box-shadow: 0 4px 15px rgba(0,0,0,0.07);
        }

        @media (max-width: 700px) {

            header {
                padding: 18px 20px;
            }

            .brand {
                font-size: 20px;
            }

            .container {
                margin: 25px auto;
            }

            .search-form {
                flex-direction: column;
            }

            .search-form input {
                min-width: 100%;
            }

        }

    </style>

</head>

<body>

<header>

    <a class="brand" href="index.php">
        📚 College Library
    </a>

    <nav>

        <a href="index.php">Home</a>

        <a href="books.php">Catalog</a>

        <a href="my_books.php">My Books</a>

        <a href="login.php">Login</a>

    </nav>

</header>


<main class="container">

    <div class="page-header">

        <h1>📚 Book Catalog</h1>

        <div class="book-count">
            Books Found:
            <strong><?= $books->num_rows ?></strong>
        </div>

    </div>


    <div class="search-card">

        <form method="get" class="search-form">

            <input
                name="q"
                placeholder="🔍 Search by title, author or category..."
                value="<?= e($q) ?>"
            >

            <button type="submit">
                Search
            </button>

            <a href="books.php" class="clear-btn">
                Clear
            </a>

        </form>

    </div>


    <?php if ($books->num_rows > 0): ?>

        <div class="grid">

            <?php while ($b = $books->fetch_assoc()): ?>

                <article class="book-card">

                    <div class="book-icon">
                        📖
                    </div>

                    <h3>
                        <?= e($b['title']) ?>
                    </h3>

                    <p class="book-info">
                        <strong>Author:</strong>
                        <?= e($b['author']) ?>
                    </p>

                    <p class="book-info">
                        <strong>Category:</strong>
                        <?= e($b['category']) ?>
                    </p>


                    <?php if ((int)$b['available'] > 0): ?>

                        <div class="availability available">
                            🟢 Available:
                            <?= e($b['available']) ?>
                            / <?= e($b['quantity']) ?>
                        </div>

                    <?php else: ?>

                        <div class="availability unavailable">
                            🔴 Currently unavailable
                        </div>

                    <?php endif; ?>


                    <a
                        class="btn"
                        href="book_details.php?id=<?= e($b['id']) ?>"
                    >
                        📖 View Details
                    </a>

                </article>

            <?php endwhile; ?>

        </div>

    <?php else: ?>

        <div class="empty">

            <h3>📭 No books found</h3>

            <p>
                Try searching with a different title, author, or category.
            </p>

        </div>

    <?php endif; ?>


</main>

</body>

</html>