<?php

require 'database.php';
require_login();

$id = (int)($_GET['id'] ?? 0);

$s = $conn->prepare(
    "SELECT id, title, author, available
     FROM books
     WHERE id=?"
);

$s->bind_param("i", $id);
$s->execute();

$b = $s->get_result()->fetch_assoc();

$msg = '';
$success = false;


/* CHECK BOOK */

if (!$b) {

    $msg = "Book not found.";

}
elseif ((int)$b['available'] < 1) {

    $msg = "This book is not currently available.";

}
else {

    /* CHECK EXISTING ACTIVE REQUEST */

    $s = $conn->prepare(
        "SELECT id
         FROM issues
         WHERE user_id=?
         AND book_id=?
         AND status IN ('Pending','Issued')"
    );

    $s->bind_param(
        "ii",
        $_SESSION['user_id'],
        $id
    );

    $s->execute();

    if ($s->get_result()->num_rows) {

        $msg = "You already have an active request for this book.";

    }
    else {

        /* CREATE REQUEST */

        $issue = date('Y-m-d');

        $due = date(
            'Y-m-d',
            strtotime('+14 days')
        );

        $s = $conn->prepare(
            "INSERT INTO issues
            (user_id,book_id,issue_date,due_date,status)
            VALUES(?,?,?,?,'Pending')"
        );

        $s->bind_param(
            "iiss",
            $_SESSION['user_id'],
            $id,
            $issue,
            $due
        );

        if ($s->execute()) {

            $msg = "Your book request has been submitted successfully.";

            $success = true;

        }
        else {

            $msg = "Unable to submit the request. Please try again.";

        }

    }

}

?>

<!doctype html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Book Request</title>

    <link
        rel="stylesheet"
        href="style.css"
    >

    <style>

        body {
            background: #f4f7fb;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        header {
            background: linear-gradient(
                135deg,
                #667eea,
                #764ba2
            );

            color: white;

            padding: 18px 40px;

            display: flex;

            justify-content: space-between;

            align-items: center;

            flex-wrap: wrap;

            gap: 15px;

            box-shadow:
                0 4px 15px rgba(0,0,0,0.15);
        }

        .brand {
            color: white;

            text-decoration: none;

            font-size: 24px;

            font-weight: bold;
        }

        nav {
            display: flex;

            gap: 10px;

            flex-wrap: wrap;
        }

        nav a {
            color: white;

            text-decoration: none;

            padding: 9px 14px;

            border-radius: 8px;
        }

        nav a:hover {
            background: rgba(255,255,255,0.2);
        }

        .container {
            max-width: 650px;

            margin: 70px auto;

            padding: 0 20px;
        }

        .request-card {
            background: white;

            border-radius: 18px;

            padding: 40px;

            text-align: center;

            box-shadow:
                0 6px 25px rgba(0,0,0,0.08);
        }

        .icon {
            font-size: 60px;

            margin-bottom: 15px;
        }

        h1 {
            color: #222;

            margin-bottom: 15px;
        }

        .message {
            font-size: 17px;

            line-height: 1.6;

            color: #555;

            margin-bottom: 25px;
        }

        .success {
            color: #155724;

            background: #d4edda;

            padding: 14px;

            border-radius: 10px;
        }

        .error {
            color: #721c24;

            background: #f8d7da;

            padding: 14px;

            border-radius: 10px;
        }

        .book-info {
            background: #f8f9ff;

            padding: 18px;

            border-radius: 10px;

            margin: 20px 0;

            text-align: left;
        }

        .book-info strong {
            color: #333;
        }

        .actions {
            margin-top: 25px;

            display: flex;

            justify-content: center;

            gap: 12px;

            flex-wrap: wrap;
        }

        .btn {
            display: inline-block;

            padding: 12px 18px;

            background: #667eea;

            color: white;

            text-decoration: none;

            border-radius: 8px;

            font-weight: bold;
        }

        .btn:hover {
            opacity: 0.9;
        }

        .secondary {
            background: #e9ecef;

            color: #333;
        }

        @media (max-width: 700px) {

            header {
                padding: 18px 20px;
            }

            .brand {
                font-size: 20px;
            }

            .container {
                margin: 40px auto;
            }

            .request-card {
                padding: 25px;
            }

        }

    </style>

</head>

<body>


<header>

    <a
        class="brand"
        href="index.php"
    >
        📚 College Library
    </a>

    <nav>

        <a href="books.php">
            Catalog
        </a>

        <a href="my_books.php">
            My Books
        </a>

        <a href="logout.php">
            Logout
        </a>

    </nav>

</header>


<main class="container">

    <div class="request-card">

        <?php if ($success): ?>

            <div class="icon">
                ✅
            </div>

            <h1>
                Request Submitted!
            </h1>

            <div class="message success">

                <?= e($msg) ?>

            </div>


            <?php if ($b): ?>

                <div class="book-info">

                    <strong>📖 Book:</strong>
                    <?= e($b['title']) ?>

                    <br><br>

                    <strong>✍️ Author:</strong>
                    <?= e($b['author']) ?>

                    <br><br>

                    <strong>📅 Request Date:</strong>
                    <?= e($issue) ?>

                    <br><br>

                    <strong>📅 Due Date:</strong>
                    <?= e($due) ?>

                    <br><br>

                    <strong>⏳ Status:</strong>
                    Pending Admin Approval

                </div>

            <?php endif; ?>


            <p class="message">
                Your request is now waiting for the librarian's approval.
                You can track its status from <strong>My Books</strong>.
            </p>


        <?php else: ?>

            <div class="icon">
                ⚠️
            </div>

            <h1>
                Request Not Submitted
            </h1>

            <div class="message error">

                <?= e($msg) ?>

            </div>

        <?php endif; ?>


        <div class="actions">

            <a
                class="btn"
                href="my_books.php"
            >
                📚 My Books
            </a>

            <a
                class="btn secondary"
                href="books.php"
            >
                ← Browse Catalog
            </a>

        </div>

    </div>

</main>

</body>

</html>