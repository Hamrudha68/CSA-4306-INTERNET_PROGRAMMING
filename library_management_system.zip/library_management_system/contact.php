<?php

require 'database.php';

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $n = trim($_POST['name'] ?? '');
    $em = trim($_POST['email'] ?? '');
    $m = trim($_POST['message'] ?? '');

    if (
        $n &&
        filter_var($em, FILTER_VALIDATE_EMAIL) &&
        $m
    ) {

        $s = $conn->prepare(
            "INSERT INTO messages(name,email,message) VALUES(?,?,?)"
        );

        $s->bind_param("sss", $n, $em, $m);
        $s->execute();

        $msg = "Message sent successfully.";

    } else {

        $msg = "Please fill all fields correctly.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Contact Library - College Library</title>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            min-height: 100vh;
            background: #f5f7fb;
            color: #222;
        }

        /* NAVIGATION */

        header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            padding: 18px 7%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
        }

        .brand {
            color: white;
            text-decoration: none;
            font-size: 25px;
            font-weight: bold;
        }

        nav {
            display: flex;
            gap: 22px;
            align-items: center;
        }

        nav a {
            color: white;
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
        }

        nav a:hover {
            opacity: 0.75;
        }

        /* MAIN */

        .page {
            max-width: 1100px;
            margin: 0 auto;
            padding: 60px 25px;
        }

        .page-heading {
            text-align: center;
            margin-bottom: 45px;
        }

        .page-heading h1 {
            font-size: 38px;
            margin-bottom: 10px;
        }

        .page-heading p {
            color: #777;
            font-size: 16px;
        }

        .contact-grid {
            display: grid;
            grid-template-columns: 0.9fr 1.1fr;
            gap: 30px;
            align-items: stretch;
        }

        /* INFORMATION CARD */

        .info-card {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-radius: 18px;
            padding: 38px;
            box-shadow: 0 12px 30px rgba(102, 126, 234, 0.2);
        }

        .info-card h2 {
            font-size: 27px;
            margin-bottom: 15px;
        }

        .info-card > p {
            line-height: 1.7;
            opacity: 0.9;
            margin-bottom: 30px;
        }

        .info-item {
            display: flex;
            gap: 15px;
            align-items: flex-start;
            margin-bottom: 24px;
        }

        .info-icon {
            width: 45px;
            height: 45px;
            background: rgba(255, 255, 255, 0.18);
            border-radius: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 21px;
            flex-shrink: 0;
        }

        .info-item h3 {
            font-size: 15px;
            margin-bottom: 5px;
        }

        .info-item p {
            font-size: 14px;
            opacity: 0.85;
            line-height: 1.5;
        }

        /* FORM */

        .form-card {
            background: white;
            padding: 38px;
            border-radius: 18px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }

        .form-card h2 {
            margin-bottom: 8px;
            font-size: 27px;
        }

        .form-subtitle {
            color: #777;
            font-size: 14px;
            margin-bottom: 25px;
        }

        .notice {
            background: #e8f8ee;
            color: #218838;
            padding: 13px;
            border-radius: 9px;
            margin-bottom: 20px;
            font-size: 14px;
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 7px;
            color: #333;
            font-weight: bold;
            font-size: 14px;
        }

        input,
        textarea {
            width: 100%;
            padding: 13px;
            border: 1px solid #ddd;
            border-radius: 9px;
            font-size: 15px;
            outline: none;
            margin-bottom: 18px;
            resize: vertical;
        }

        input:focus,
        textarea:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.12);
        }

        textarea {
            min-height: 140px;
        }

        button {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 9px;
            background: #667eea;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        button:hover {
            background: #5568d9;
            transform: translateY(-1px);
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 25px;
            color: #667eea;
            text-decoration: none;
            font-weight: bold;
            font-size: 14px;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        /* FOOTER */

        footer {
            background: #20232a;
            color: #ccc;
            text-align: center;
            padding: 25px;
            font-size: 14px;
            margin-top: 20px;
        }

        footer strong {
            color: white;
        }

        /* RESPONSIVE */

        @media (max-width: 800px) {

            header {
                flex-direction: column;
                gap: 15px;
            }

            nav {
                flex-wrap: wrap;
                justify-content: center;
            }

            .contact-grid {
                grid-template-columns: 1fr;
            }

        }

        @media (max-width: 500px) {

            .page {
                padding: 40px 18px;
            }

            .page-heading h1 {
                font-size: 30px;
            }

            .info-card,
            .form-card {
                padding: 27px;
            }

            .brand {
                font-size: 21px;
            }

        }

    </style>

</head>

<body>

    <!-- NAVIGATION -->

    <header>

        <a href="index.php" class="brand">
            📚 College Library
        </a>

        <nav>

            <a href="index.php">Home</a>

            <a href="books.php">Catalog</a>

            <a href="my_books.php">My Books</a>

            <a href="login.php">Student Login</a>

        </nav>

    </header>


    <!-- MAIN CONTENT -->

    <main class="page">

        <div class="page-heading">

            <h1>
                Contact the Library
            </h1>

            <p>
                Have a question or need help? Send us a message.
            </p>

        </div>


        <div class="contact-grid">

            <!-- INFORMATION -->

            <div class="info-card">

                <h2>
                    Get in Touch
                </h2>

                <p>
                    Our library team is here to help students
                    with book requests, account questions,
                    and general library assistance.
                </p>


                <div class="info-item">

                    <div class="info-icon">
                        📍
                    </div>

                    <div>

                        <h3>
                            Location
                        </h3>

                        <p>
                            College Library<br>
                            Main Campus
                        </p>

                    </div>

                </div>


                <div class="info-item">

                    <div class="info-icon">
                        ✉️
                    </div>

                    <div>

                        <h3>
                            Email
                        </h3>

                        <p>
                            library@college.edu
                        </p>

                    </div>

                </div>


                <div class="info-item">

                    <div class="info-icon">
                        📞
                    </div>

                    <div>

                        <h3>
                            Library Support
                        </h3>

                        <p>
                            Contact the library administration
                            for assistance.
                        </p>

                    </div>

                </div>

            </div>


            <!-- CONTACT FORM -->

            <div class="form-card">

                <h2>
                    Send a Message
                </h2>

                <p class="form-subtitle">
                    Fill in the form below and we'll receive your message.
                </p>


                <?php if ($msg): ?>

                    <p class="notice">
                        <?= e($msg) ?>
                    </p>

                <?php endif; ?>


                <form method="post">

                    <label>
                        Your Name
                    </label>

                    <input
                        type="text"
                        name="name"
                        placeholder="Enter your name"
                        required
                    >


                    <label>
                        Email Address
                    </label>

                    <input
                        type="email"
                        name="email"
                        placeholder="Enter your email"
                        required
                    >


                    <label>
                        Message
                    </label>

                    <textarea
                        name="message"
                        placeholder="Write your message here..."
                        rows="5"
                        required
                    ></textarea>


                    <button type="submit">
                        ✉️ Send Message
                    </button>

                </form>


                <a href="index.php" class="back-link">
                    ← Back to Home
                </a>

            </div>

        </div>

    </main>


    <!-- FOOTER -->

    <footer>

        <p>
            © 2026 <strong>College Library Management System</strong>
        </p>

        <p>
            Simple and convenient library management for students.
        </p>

    </footer>

</body>

</html>