<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>College Library - Library Management System</title>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            min-height: 100vh;
            background: #f5f7fb;
            color: #222;
        }

        /* NAVBAR */

        header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            padding: 18px 7%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
        }

        .brand {
            color: white;
            text-decoration: none;
            font-size: 25px;
            font-weight: bold;
        }

        nav {
            display: flex;
            gap: 25px;
            align-items: center;
        }

        nav a {
            color: white;
            text-decoration: none;
            font-size: 15px;
            font-weight: bold;
            transition: 0.3s;
        }

        nav a:hover {
            opacity: 0.75;
        }

        .login-btn {
            background: white;
            color: #667eea !important;
            padding: 9px 18px;
            border-radius: 8px;
        }

        /* HERO */

        .hero {
            min-height: 500px;
            padding: 70px 7%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 50px;
            background:
                linear-gradient(
                    135deg,
                    #eef1ff,
                    #f8f3ff
                );
        }

        .hero-content {
            max-width: 600px;
        }

        .hero-content h1 {
            font-size: 48px;
            line-height: 1.15;
            margin-bottom: 20px;
            color: #222;
        }

        .hero-content h1 span {
            color: #667eea;
        }

        .hero-content p {
            color: #666;
            font-size: 18px;
            line-height: 1.7;
            margin-bottom: 30px;
        }

        .buttons {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .btn {
            display: inline-block;
            padding: 14px 24px;
            border-radius: 9px;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }

        .primary-btn {
            background: #667eea;
            color: white;
        }

        .primary-btn:hover {
            background: #5568d9;
            transform: translateY(-2px);
        }

        .secondary-btn {
            background: white;
            color: #667eea;
            border: 1px solid #667eea;
        }

        .secondary-btn:hover {
            background: #667eea;
            color: white;
        }

        /* HERO BOOK ICON */

        .hero-image {
            width: 360px;
            height: 360px;
            border-radius: 50%;
            background: white;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 150px;
            box-shadow: 0 20px 50px rgba(102, 126, 234, 0.2);
        }

        /* FEATURES */

        .features {
            padding: 60px 7%;
            text-align: center;
        }

        .section-title {
            font-size: 32px;
            margin-bottom: 10px;
        }

        .section-subtitle {
            color: #777;
            margin-bottom: 40px;
        }

        .feature-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 25px;
        }

        .feature-card {
            background: white;
            padding: 30px 25px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            transition: 0.3s;
        }

        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.12);
        }

        .feature-icon {
            font-size: 42px;
            margin-bottom: 15px;
        }

        .feature-card h3 {
            margin-bottom: 10px;
            color: #333;
        }

        .feature-card p {
            color: #777;
            line-height: 1.6;
            font-size: 14px;
        }

        /* QUICK ACCESS */

        .quick-access {
            padding: 20px 7% 70px;
        }

        .quick-box {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 45px;
            border-radius: 18px;
            text-align: center;
        }

        .quick-box h2 {
            font-size: 30px;
            margin-bottom: 12px;
        }

        .quick-box p {
            margin-bottom: 25px;
            opacity: 0.9;
        }

        .quick-buttons {
            display: flex;
            justify-content: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        .quick-btn {
            background: white;
            color: #667eea;
            padding: 12px 22px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
        }

        /* FOOTER */

        footer {
            background: #20232a;
            color: #ccc;
            text-align: center;
            padding: 25px;
            font-size: 14px;
        }

        footer strong {
            color: white;
        }

        /* RESPONSIVE */

        @media (max-width: 850px) {

            header {
                flex-direction: column;
                gap: 15px;
            }

            nav {
                gap: 15px;
                flex-wrap: wrap;
                justify-content: center;
            }

            .hero {
                flex-direction: column;
                text-align: center;
                padding: 55px 6%;
            }

            .hero-content h1 {
                font-size: 38px;
            }

            .buttons {
                justify-content: center;
            }

            .hero-image {
                width: 250px;
                height: 250px;
                font-size: 100px;
            }

            .feature-grid {
                grid-template-columns: 1fr;
            }

        }

        @media (max-width: 500px) {

            .brand {
                font-size: 21px;
            }

            .hero-content h1 {
                font-size: 32px;
            }

            .hero-content p {
                font-size: 16px;
            }

            .quick-box {
                padding: 30px 20px;
            }

        }

    </style>

</head>

<body>

    <!-- NAVIGATION -->

    <header>

        <a href="index.php" class="brand">
            📚 College Library
        </a>

        <nav>

            <a href="index.php">Home</a>

            <a href="books.php">Catalog</a>

            <a href="my_books.php">My Books</a>

            <a href="login.php" class="login-btn">
                Student Login
            </a>

        </nav>

    </header>


    <!-- HERO SECTION -->

    <section class="hero">

        <div class="hero-content">

            <h1>
                Welcome to the
                <span>College Library</span>
            </h1>

            <p>
                Discover books, manage your borrowing requests,
                and explore a smarter and easier way to access
                your college library resources.
            </p>

            <div class="buttons">

                <a href="books.php" class="btn primary-btn">
                    📚 Browse Books
                </a>

                <a href="register.php" class="btn secondary-btn">
                    📝 Create Account
                </a>

            </div>

        </div>


        <div class="hero-image">
            📖
        </div>

    </section>


    <!-- FEATURES -->

    <section class="features">

        <h2 class="section-title">
            Everything You Need
        </h2>

        <p class="section-subtitle">
            Simple tools for managing your library experience
        </p>


        <div class="feature-grid">

            <div class="feature-card">

                <div class="feature-icon">
                    🔎
                </div>

                <h3>
                    Find Books Easily
                </h3>

                <p>
                    Search the library catalog by book title,
                    author, or category and quickly find
                    the books you need.
                </p>

            </div>


            <div class="feature-card">

                <div class="feature-icon">
                    📚
                </div>

                <h3>
                    Request Books
                </h3>

                <p>
                    Submit book requests online and track
                    their approval status directly from
                    your student account.
                </p>

            </div>


            <div class="feature-card">

                <div class="feature-icon">
                    📋
                </div>

                <h3>
                    Track Your Books
                </h3>

                <p>
                    View your requested and borrowed books,
                    due dates, return status, and borrowing
                    history in one place.
                </p>

            </div>

        </div>

    </section>


    <!-- QUICK ACCESS -->

    <section class="quick-access">

        <div class="quick-box">

            <h2>
                Ready to explore the library?
            </h2>

            <p>
                Browse available books or sign in to manage
                your requests.
            </p>

            <div class="quick-buttons">

                <a href="books.php" class="quick-btn">
                    📖 View Catalog
                </a>

                <a href="login.php" class="quick-btn">
                    🔐 Student Login
                </a>

                <a href="admin/login.php" class="quick-btn">
                    ⚙️ Admin Login
                </a>

            </div>

        </div>

    </section>


    <!-- FOOTER -->

    <footer>

        <p>
            © 2026 <strong>College Library Management System</strong>
        </p>

        <p>
            A simple digital library solution for students and administrators.
        </p>

    </footer>

</body>

</html>