<?php

require 'database.php';
require_login();

$s = $conn->prepare(
    "SELECT i.*, b.title, b.author
     FROM issues i
     JOIN books b ON b.id=i.book_id
     WHERE i.user_id=?
     ORDER BY i.id DESC"
);

$s->bind_param("i", $_SESSION['user_id']);
$s->execute();

$rows = $s->get_result();

?>

<!doctype html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Books</title>

    <link rel="stylesheet" href="style.css">

    <style>

        body {
            background: #f4f7fb;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 18px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }

        .brand {
            color: white;
            text-decoration: none;
            font-size: 24px;
            font-weight: bold;
        }

        nav {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        nav a {
            color: white;
            text-decoration: none;
            padding: 9px 14px;
            border-radius: 8px;
            transition: 0.3s;
        }

        nav a:hover {
            background: rgba(255,255,255,0.2);
        }

        .container {
            max-width: 1150px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 10px;
        }

        h1 {
            margin: 0;
            color: #222;
        }

        .welcome {
            color: #666;
            margin-bottom: 25px;
        }

        .count-card {
            background: white;
            padding: 12px 18px;
            border-radius: 10px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
            color: #555;
        }

        .search-box {
            background: white;
            padding: 18px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
        }

        .search-box input {
            width: 100%;
            box-sizing: border-box;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 15px;
            outline: none;
        }

        .search-box input:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102,126,234,0.12);
        }

        .table-card {
            background: white;
            border-radius: 14px;
            overflow-x: auto;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 850px;
        }

        th {
            background: #667eea;
            color: white;
            padding: 15px;
            text-align: left;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #eee;
            color: #444;
        }

        tr:hover td {
            background: #f8f9ff;
        }

        .book-title {
            font-weight: bold;
            color: #333;
        }

        .author {
            font-size: 13px;
            color: #777;
            margin-top: 4px;
        }

        .status {
            display: inline-block;
            padding: 7px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: bold;
        }

        .pending {
            background: #fff3cd;
            color: #856404;
        }

        .issued {
            background: #d1ecf1;
            color: #0c5460;
        }

        .rejected {
            background: #f8d7da;
            color: #721c24;
        }

        .returned {
            background: #d4edda;
            color: #155724;
        }

        .overdue {
            background: #f8d7da;
            color: #721c24;
            display: inline-block;
            padding: 5px 9px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: bold;
            margin-top: 5px;
        }

        .empty {
            text-align: center;
            padding: 35px;
            color: #888;
        }

        .btn {
            display: inline-block;
            margin-top: 22px;
            padding: 11px 18px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
        }

        .btn:hover {
            opacity: 0.9;
        }

        @media (max-width: 700px) {

            header {
                padding: 18px 20px;
            }

            .brand {
                font-size: 20px;
            }

            .container {
                margin: 25px auto;
            }

        }

    </style>

</head>

<body>

<header>

    <a class="brand" href="index.php">
        📚 College Library
    </a>

    <nav>
        <a href="books.php">Catalog</a>
        <a href="my_books.php">My Books</a>
        <a href="logout.php">Logout</a>
    </nav>

</header>


<main class="container">

    <div class="page-header">

        <h1>📚 My Books</h1>

        <div class="count-card">
            Total Requests:
            <strong><?= $rows->num_rows ?></strong>
        </div>

    </div>


    <p class="welcome">
        Welcome,
        <strong><?= e($_SESSION['user_name']) ?></strong>!
        Here you can track your book requests and borrowed books.
    </p>


    <div class="search-box">

        <input
            type="text"
            id="bookSearch"
            placeholder="🔍 Search by book title, author, or status..."
            onkeyup="searchBooks()"
        >

    </div>


    <div class="table-card">

        <table id="booksTable">

            <thead>

                <tr>
                    <th>Book</th>
                    <th>Request Date</th>
                    <th>Due Date</th>
                    <th>Status</th>
                    <th>Returned Date</th>
                </tr>

            </thead>

            <tbody>

            <?php if ($rows->num_rows > 0): ?>

                <?php while ($r = $rows->fetch_assoc()): ?>

                    <?php

                    $status = $r['status'];

                    $isOverdue = false;

                    if (
                        $status === 'Issued' &&
                        !empty($r['due_date']) &&
                        $r['due_date'] < date('Y-m-d')
                    ) {
                        $isOverdue = true;
                    }

                    ?>

                    <tr>

                        <td>

                            <div class="book-title">
                                📖 <?= e($r['title']) ?>
                            </div>

                            <div class="author">
                                By <?= e($r['author']) ?>
                            </div>

                        </td>


                        <td>
                            <?= e($r['issue_date']) ?>
                        </td>


                        <td>

                            <?= e($r['due_date']) ?>

                            <?php if ($isOverdue): ?>

                                <div class="overdue">
                                    ⚠️ Overdue
                                </div>

                            <?php endif; ?>

                        </td>


                        <td>

                            <?php if ($status === 'Pending'): ?>

                                <span class="status pending">
                                    ⏳ Pending
                                </span>

                            <?php elseif ($status === 'Issued'): ?>

                                <span class="status issued">
                                    📚 Issued
                                </span>

                            <?php elseif ($status === 'Rejected'): ?>

                                <span class="status rejected">
                                    ❌ Rejected
                                </span>

                            <?php elseif ($status === 'Returned'): ?>

                                <span class="status returned">
                                    ✅ Returned
                                </span>

                            <?php else: ?>

                                <span class="status">
                                    <?= e($status) ?>
                                </span>

                            <?php endif; ?>

                        </td>


                        <td>

                            <?= e($r['return_date'] ?? '—') ?>

                        </td>

                    </tr>

                <?php endwhile; ?>

            <?php else: ?>

                <tr>

                    <td colspan="5" class="empty">

                        📭 You have not requested any books yet.

                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>


    <a class="btn" href="books.php">
        📚 Browse Books
    </a>

</main>


<script>

function searchBooks() {

    const input = document.getElementById("bookSearch");

    const filter = input.value.toLowerCase();

    const table = document.getElementById("booksTable");

    const rows = table.getElementsByTagName("tr");


    for (let i = 1; i < rows.length; i++) {

        const text = rows[i].textContent.toLowerCase();

        if (text.includes(filter)) {
            rows[i].style.display = "";
        } else {
            rows[i].style.display = "none";
        }

    }

}

</script>

</body>

</html>