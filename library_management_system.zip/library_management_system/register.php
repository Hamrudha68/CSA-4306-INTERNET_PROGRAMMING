<?php

require 'database.php';

$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $pw = $_POST['password'] ?? '';

    if (
        !$name ||
        !filter_var($email, FILTER_VALIDATE_EMAIL) ||
        strlen($pw) < 6
    ) {

        $err = "Enter a name, valid email and password (minimum 6 characters).";

    } else {

        $hash = password_hash($pw, PASSWORD_DEFAULT);

        $s = $conn->prepare(
            "INSERT INTO users(name,email,password) VALUES(?,?,?)"
        );

        $s->bind_param("sss", $name, $email, $hash);

        if ($s->execute()) {

            header("Location: login.php?registered=1");
            exit;

        } else {

            $err = "Email already registered.";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Student Registration - College Library</title>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background:
                linear-gradient(135deg, #667eea, #764ba2);
            padding: 20px;
        }

        .register-container {
            width: 430px;
            max-width: 100%;
            background: white;
            padding: 42px;
            border-radius: 20px;
            box-shadow: 0 18px 45px rgba(0, 0, 0, 0.25);
        }

        .logo {
            width: 75px;
            height: 75px;
            margin: 0 auto 18px;
            border-radius: 50%;
            background: #eef0ff;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 38px;
        }

        h1 {
            text-align: center;
            color: #222;
            margin-bottom: 8px;
            font-size: 28px;
        }

        .subtitle {
            text-align: center;
            color: #777;
            font-size: 14px;
            line-height: 1.5;
            margin-bottom: 28px;
        }

        .error {
            background: #ffe7e7;
            color: #d63031;
            padding: 12px;
            border-radius: 9px;
            text-align: center;
            margin-bottom: 18px;
            font-size: 14px;
            line-height: 1.4;
        }

        label {
            display: block;
            margin-bottom: 7px;
            color: #333;
            font-weight: bold;
            font-size: 14px;
        }

        input {
            width: 100%;
            padding: 14px;
            margin-bottom: 18px;
            border: 1px solid #ddd;
            border-radius: 9px;
            font-size: 15px;
            outline: none;
            transition: 0.2s;
        }

        input:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.12);
        }

        .password-box {
            position: relative;
        }

        .password-box input {
            padding-right: 65px;
        }

        .show-password {
            position: absolute;
            right: 13px;
            top: 14px;
            color: #667eea;
            cursor: pointer;
            font-size: 13px;
            font-weight: bold;
        }

        .password-hint {
            margin-top: -10px;
            margin-bottom: 18px;
            color: #777;
            font-size: 12px;
        }

        button {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 9px;
            background: #667eea;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        button:hover {
            background: #5568d9;
            transform: translateY(-1px);
        }

        .login-text {
            text-align: center;
            margin-top: 22px;
            color: #666;
            font-size: 14px;
        }

        .login-text a {
            color: #667eea;
            font-weight: bold;
            text-decoration: none;
        }

        .login-text a:hover {
            text-decoration: underline;
        }

        .home-link {
            display: block;
            text-align: center;
            margin-top: 18px;
            color: #777;
            text-decoration: none;
            font-size: 14px;
        }

        .home-link:hover {
            color: #667eea;
        }

        @media (max-width: 480px) {

            .register-container {
                padding: 32px 24px;
            }

            h1 {
                font-size: 25px;
            }

        }

    </style>

</head>

<body>

    <div class="register-container">

        <div class="logo">📚</div>

        <h1>Create Account</h1>

        <p class="subtitle">
            Register as a student to access the College Library
        </p>

        <?php if ($err): ?>

            <p class="error">
                <?= e($err) ?>
            </p>

        <?php endif; ?>

        <form method="post">

            <label>Full Name</label>

            <input
                type="text"
                name="name"
                placeholder="Enter your full name"
                required
            >

            <label>Email Address</label>

            <input
                type="email"
                name="email"
                placeholder="Enter your email address"
                required
            >

            <label>Password</label>

            <div class="password-box">

                <input
                    type="password"
                    name="password"
                    id="password"
                    placeholder="Create a password"
                    minlength="6"
                    required
                >

                <span
                    class="show-password"
                    id="toggleText"
                    onclick="togglePassword()"
                >
                    Show
                </span>

            </div>

            <p class="password-hint">
                Password must contain at least 6 characters.
            </p>

            <button type="submit">
                📝 Create Account
            </button>

        </form>

        <p class="login-text">
            Already have an account?
            <a href="login.php">Login here</a>
        </p>

        <a href="index.php" class="home-link">
            ← Back to Home
        </a>

    </div>

    <script>

        function togglePassword() {

            const password = document.getElementById("password");
            const toggleText = document.getElementById("toggleText");

            if (password.type === "password") {

                password.type = "text";
                toggleText.textContent = "Hide";

            } else {

                password.type = "password";
                toggleText.textContent = "Show";

            }

        }

    </script>

</body>

</html>